<?xml version="1.0" encoding="UTF-8"?>

<pluginstate>
  <version file="1" date="2026-11-11-03-41"/>
  <PLUGIN name="Plugin Manager G2" descriptiveName="Plugin Manager G2" format="VST" category="Synth" manufacturer="OpenMPC"
          version="1.0" file="%payload-path%/OpenMPC - VST - Plugin Manager G2/openmpc_pm_g2.so" uid="4f4d4732" isInstrument="1" fileTime="0"
          infoUpdateTime="0" numInputs="0" numOutputs="2" isShell="0"/>
  <preset>Default</preset>
  <state>161.CMlaKA....fQBMDZ....A7TSGIC....Y....A...............................................................................................................................................................................A..</state>
</pluginstate>

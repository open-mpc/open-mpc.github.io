OpenMPC Plugin Manager VST stick (version 1.1.1).

Copy everything in this folder (hidden files too) to the root of an empty USB stick, insert it into the MPC or Force and
confirm the prompt. The plugin manager is installed in the device's own plugin folder and MPC restarts once. Save your project
first. It works with MPC OS 3.9.1 and older; MPC OS 3.10 has no USB prompt (use the plugin manager stick there).
The result is written to g2-install-result.txt on the stick, and a copy of MPC.settings to MPC.settings.backup.
